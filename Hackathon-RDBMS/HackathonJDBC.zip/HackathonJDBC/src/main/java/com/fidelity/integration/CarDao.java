package com.fidelity.integration;

import java.util.List;

import com.fidelity.model.Car;

public interface CarDao {
	List<Car> getCars();
	void insertCar(Car car);
	void deleteCar(int carId);

	void close();
}
