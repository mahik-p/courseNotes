package com.fidelity.model;

public class Car {

	private int carID;
	private String carName;
	private String carMake;
	private CarType carType;
	private float engineSize;

	
	// Eclipse-generated from here

	public Car(int carID, String carName, String carMake, CarType carType, float engineSize) {
		super();
		this.carID = carID;
		this.carName = carName;
		this.carMake = carMake;
		this.carType = carType;
		this.engineSize = engineSize;
	}
	
	
}
