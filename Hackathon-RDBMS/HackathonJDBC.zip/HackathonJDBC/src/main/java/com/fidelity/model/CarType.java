package com.fidelity.model;

public enum CarType {
	SEDAN("S"), TRUCK("T"), CONVERTIBLE("C");

	private String code;

	private CarType(String code) {
		this.code = code;
	}

	public static CarType of(String code) {
		for (CarType ct: values()) {
			if (ct.code.equals(code)) {
				return ct;
			}
		}
		throw new IllegalArgumentException("Unknown car type code");
	}

	public String getCode() {
		return code;
	}
}
