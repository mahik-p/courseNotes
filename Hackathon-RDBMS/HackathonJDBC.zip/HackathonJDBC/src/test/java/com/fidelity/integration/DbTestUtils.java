/*
 * DbTestUtils.java - utility functions for database integration tests.
 */

package com.fidelity.integration;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.core.io.FileSystemResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import com.fidelity.model.Car;
import com.fidelity.model.CarType;

public enum DbTestUtils {
	INSTANCE;

	private static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/xepdb1";
	private static final String USER = "scott";
	private static final String PASSWORD = "TIGER";

	private static final String SQL_SCRIPT = "sql/HackathonJDBC.sql";

	private Connection connection;

	/**
	 * Re-run the database initialization script.
	 *
	 * Alternatively, for simple schemas, we could drop all rows in the required
	 * tables, then insert test data: Statement stmt = connection.createStatement();
	 * stmt.executeUpdate("delete from emp"); stmt.executeUpdate("insert into emp
	 * (empno,ename,job,...) values (7369,'SMITH','CLERK',...)"); ... stmt.close();
	 */
	public void initDb() {
		try {
			if (connection == null) {
				connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			}
			// run DB scripts

			ResourceDatabasePopulator resourceDatabasePopulator = new ResourceDatabasePopulator();
			// Only pure SQL scripts allowed - PL/SQL statements must be removed
			resourceDatabasePopulator.setContinueOnError(true);
			resourceDatabasePopulator.addScript(new FileSystemResource(SQL_SCRIPT));
			resourceDatabasePopulator.populate(connection);
			Thread.sleep(500);
		} catch (Exception e) {
			close();
			throw new RuntimeException(e);
		}
		// if no errors, keep connection open
	}

	public synchronized JdbcTemplate initJdbcTemplate() {
		try {
			if (connection == null) {
				connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			}
			return new JdbcTemplate(new SingleConnectionDataSource(connection, true));
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public synchronized void close() {
		if (connection != null) {
			try {
				connection.close();
				connection = null;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}
	}

	/**
	 * Assert a Client instance has the same property values as the columnValueMap.
	 * 
	 * @param client         a Client instance
	 * @param carsProperties a Map returned by JdbcTemplate.queryForMap. The key for
	 *                       each item is a column name, and the value is the
	 *                       column's value.
	 */

	public void assertCarEquals(Car theCar, Map<String, Object> carsProperties) {
		CarType carTypeFromDb = CarType.of((String) carsProperties.get("cartype"));
		// TODO
		assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, intValue(carsProperties.get("car_id")));
		assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, carsProperties.get("car_name"));
		assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, carsProperties.get("car_make"));
		assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, carTypeFromDb);
		assertEquals(/*REPLACE null with appropriate client.getXXX() call */ null, floatValue(carsProperties.get("engine_size_l")));
	}

	private int intValue(Object bigDecimal) {
		return bigDecimal != null ? ((BigDecimal) bigDecimal).intValue() : 0;
	}

	private float floatValue(Object bigDecimal) {
		return bigDecimal != null ? ((BigDecimal) bigDecimal).floatValue() : 0;
	}

	public void assertCarsEquals(List<Car> cars, List<Map<String, Object>> carsProperties) {
		assertEquals(cars.size(), carsProperties.size());
		for (int i = 0; i < cars.size(); i++) {
			assertCarEquals(cars.get(i), carsProperties.get(i));
		}
	}
}
