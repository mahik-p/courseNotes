package com.roifmr.presidents.restservices;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.jdbc.JdbcTestUtils;
import com.roifmr.presidents.business.President;

@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Sql({"classpath:schema.sql", "classpath:data.sql"}) 
public class PresidentsServiceE2eTest {

	@Autowired
	private TestRestTemplate restTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplate; 
	
	@Test
	public void testQueryForAllPresidents() {
		
		int presidentCount = JdbcTestUtils.countRowsInTable(jdbcTemplate, "presidents");
		
		String request = "/president/presidents";
		
		ResponseEntity<President[]> response = restTemplate.getForEntity(request, President[].class);
		
		// verify the response HTTP status
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.OK)));
		
		// verify that the service returned all Widgets in the database
		President[] responseWidgets = response.getBody();
		assertThat(responseWidgets.length, is(equalTo(presidentCount))); 
	}
	
	@Test
	public void testQueryForAllPresident_NoWidgetsInDb() {
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "presidents");
		String request = "/president/presidents";
		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		
		// verify that the response body is empty
		assertThat(response.getBody(), is(emptyOrNullString()));
	}
	
	@Test
	public void testQueryForAllPresidents_DbException() {
		// drop the Widgets table to force a database exception
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "presidents");
		String request = "/president/presidents";
		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
	}
	
	@Test
	public void testQueryPresidentBioUsingID() {
		String request = "/president/president/1";
	
		ResponseEntity<String> response = restTemplate.getForEntity(request,String.class);
		
		// verify the response HTTP status
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.OK)));
		String r = response.getBody();
		
		assertEquals(r, "On April 30, 1789, George Washington, standing on the balcony of Federal Hall on Wall Street in New York, took his oath of office as the first President of the United States. \"As the first of every thing, in our situation will serve to establish a Precedent,\" he wrote James Madison, \"it is devoutly wished on my part, that these precedents may be fixed on true principles.\" Born in 1732 into a Virginia planter family, he learned the morals, manners, and body of knowledge requisite for an 18th century Virginia gentleman.");

	}
	
	@Test
	public void testQueryForInvalidID() {
		String request = "/president/president/0";
		
		ResponseEntity<String> response = restTemplate.getForEntity(request,String.class);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
	}
	
	@Test
	public void testQueryForAllPresidentBioId_DbException() {
		// drop the Widgets table to force a database exception
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "presidents");
		String request = "/president/president/1";
		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
	}
	
}










