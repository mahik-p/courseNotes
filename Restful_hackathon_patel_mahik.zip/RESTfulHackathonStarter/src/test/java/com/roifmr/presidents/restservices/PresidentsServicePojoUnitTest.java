package com.roifmr.presidents.restservices;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import com.roifmr.presidents.business.President;
import com.roifmr.presidents.integration.PresidentsDao;

public class PresidentsServicePojoUnitTest {

	@Mock
	PresidentsDao dao;
	
	@InjectMocks
	private PresidentsService service;
	
	@BeforeEach
	public void setUp() {
		service = new PresidentsService();
		
		MockitoAnnotations.openMocks(this); // required initialize all mocks
	}
	
	@Test
	public void testQueryForAllPresidents_ListLength2_ReturnsStatus200() {
		// Initialize the list of Gadgets that will be returned by the mock DAO
		List<President> p = Arrays.asList(
				new President(1,"George", "Washington",1789,1797,"georgewashington.jpg","On April 30"), 
				new President(2,"G", "W",1,7,"geo","O")
				);
		// Configure the mock DAO to return the list of Gadgets when 
		// its getAllPresidents() method is called by the PresidentService
		when( dao.queryForAllPresidents() )
        .thenReturn(p);
		
		//--------- Act: call the method being tested -------------------------
		
		// call a service method with a plain Java call: no HTTP request is created
		ResponseEntity<List<President>> response = service.queryForAllPresidents();
		
		// Verify correct HTTP status
		assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
		
		// Verify response body content
		assertThat(response.getBody(), equalTo(p));
		
	}
	
	@Test
	public void testQueryForAllPresident_EmptyList_ReturnsStatus204() {
		// Configure the mock DAO to return an empty list when
		// its getAllGadgets() method is called
		when( dao.queryForAllPresidents() )
		             .thenReturn(new ArrayList<President>());

		ResponseEntity<List<President>> response = service.queryForAllPresidents();
		
		assertThat(response.getStatusCode(), equalTo(HttpStatus.NO_CONTENT));
		assertThat(response.getBody(), is(nullValue()));
	}
	
	@Test
	public void testQueryForAllPresident_DaoThrowsException_ReturnsStatus500() {
		// Configure the mock DAO to throw an unchecked exception when
		// its getAllGadgets() method is called
		when( dao.queryForAllPresidents() )
		             .thenThrow(new IllegalStateException());

		ResponseStatusException ex = assertThrows(ResponseStatusException.class, () ->
			service.queryForAllPresidents()
		);
		
		assertThat(ex.getStatus(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testQueryPresidentBio_returns200() {
		// Initialize the list of Gadgets that will be returned by the mock DAO
		String bio = "bio";
		// Configure the mock DAO to return the list of Gadgets when 
		// its getAllPresidents() method is called by the PresidentService
		when( dao.queryForPresidentBiography(1) )
        .thenReturn(bio);
		
		//--------- Act: call the method being tested -------------------------
		
		// call a service method with a plain Java call: no HTTP request is created
		ResponseEntity<String> response = service.queryForBioById(1);
		
		// Verify correct HTTP status
		assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
		
		// Verify response body content
		assertThat(response.getBody(), equalTo(bio));
	}
	
	
	@Test
	public void testQueryPresidentBio_return204() {
		// Configure the mock DAO to return an empty list when
		// its getAllGadgets() method is called
		when( dao.queryForPresidentBiography(1))
		             .thenReturn(null);

		ResponseEntity<String> response = service.queryForBioById(1);
		
		assertThat(response.getStatusCode(), equalTo(HttpStatus.NO_CONTENT));
		assertThat(response.getBody(), is(nullValue()));
	}
	
	@Test 
	public void testQueryPresidentBio_return500() {
		// Configure the mock DAO to throw an unchecked exception when
		// its getAllGadgets() method is called
		when( dao.queryForPresidentBiography(1) )
		             .thenThrow(new IllegalStateException());

		ResponseStatusException ex = assertThrows(ResponseStatusException.class, () ->
			service.queryForBioById(1)
		);
		
		assertThat(ex.getStatus(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
	}
	
}
