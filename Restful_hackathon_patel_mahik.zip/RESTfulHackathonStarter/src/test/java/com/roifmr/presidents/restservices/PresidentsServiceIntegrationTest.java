package com.roifmr.presidents.restservices;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.roifmr.presidents.business.President;
import com.roifmr.presidents.integration.PresidentsDao;

@SpringBootTest
@Transactional
public class PresidentsServiceIntegrationTest {


	@Autowired
	PresidentsDao dao;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Test 
	public void queryForAllPresidents() {
		List<President> p = dao.queryForAllPresidents();
		
		assertEquals(p.size(), 10);
	}
	
	@Test 
	public void  queryForPresidentBiography() {
		String bio = dao.queryForPresidentBiography(1);
		
		assertEquals(bio, "On April 30, 1789, George Washington, standing on the balcony of Federal Hall on Wall Street in New York, took his oath of office as the first President of the United States. \"As the first of every thing, in our situation will serve to establish a Precedent,\" he wrote James Madison, \"it is devoutly wished on my part, that these precedents may be fixed on true principles.\" Born in 1732 into a Virginia planter family, he learned the morals, manners, and body of knowledge requisite for an 18th century Virginia gentleman.");
	}
}
