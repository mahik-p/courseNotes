package com.roifmr.presidents.restservices;

import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.roifmr.presidents.business.President;
import com.roifmr.presidents.integration.PresidentsDao;

@WebMvcTest(PresidentsService.class)
public class PresidentsServiceWebLayerTest {
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	private PresidentsDao dao;
	
	private static List<President> presidents;
	
	private static String bio;
	
	@BeforeAll
	public static void init() {
		presidents = Arrays.asList(
				new President(1,"George", "Washington",1789,1797,"georgewashington.jpg","On April 30"), 
				new President(2,"G", "W",1,7,"geo","O")
				);
		bio = "bio";
	}
	
	@Test
	public void testQueryForAllPresidents() throws Exception {
		when(dao.queryForAllPresidents()).thenReturn(presidents);
		
		mockMvc.perform(get("/president/presidents"))
		   .andDo(print())
		   .andExpect(status().isOk())
		   .andExpect(jsonPath("$.length()").value(2));
	}
	
	@Test
	public void testQueryForAllPresident_DaoReturnsEmptyList() throws Exception {
		when(dao.queryForAllPresidents()).thenReturn(new ArrayList<President>());
				
		mockMvc.perform(get("/president/presidents"))
			.andDo(print())
			.andExpect(status().isNoContent())
			.andExpect(content().string(is(emptyOrNullString())));
	}
	
	@Test
	public void testQueryForAllPresident_DaoThrowsException() throws Exception {
		when(dao.queryForAllPresidents()).thenThrow(new RuntimeException());		
		mockMvc.perform(get("/president/presidents"))
			   .andDo(print())
			   .andExpect(status().is5xxServerError())
			   .andExpect(content().string(is(emptyOrNullString())));
	}
	
	@Test
	public void testQueryForAllPresidentBio() throws Exception {
		when(dao.queryForPresidentBiography(1)).thenReturn(bio);
		
		mockMvc.perform(get("/president/president/1"))
		   .andDo(print())
		   .andExpect(status().isOk());	
	}
	
	@Test 
	public void testQueryForAllPresidentBio_DaoReturnsEmptyList() throws Exception {
		when(dao.queryForPresidentBiography(1)).thenReturn(null);
		
		mockMvc.perform(get("/president/president/1"))
			.andDo(print())
			.andExpect(status().isNoContent())
			.andExpect(content().string(is(emptyOrNullString())));
	}

	@Test 
	public void voidtestQueryForAllPresidentBio_DaoThrowsException() throws Exception{
		when(dao.queryForPresidentBiography(1)).thenThrow(new RuntimeException());		
		mockMvc.perform(get("/president/president/1"))
			   .andDo(print())
			   .andExpect(status().is5xxServerError())
			   .andExpect(content().string(is(emptyOrNullString())));
	}
}










