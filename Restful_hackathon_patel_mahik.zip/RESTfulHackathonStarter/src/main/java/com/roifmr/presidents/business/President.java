package com.roifmr.presidents.business;

import java.util.Objects;

public class President {
	private int id;
	private String firstName;
	private String lastName;
	private int firstYear;
	private int lastYear;
	private String image;
	private String biography;
	
	
	
	public President(int id, String firstName, String lastName, int firstYear, int lastYear, String image,
			String biography) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.firstYear = firstYear;
		this.lastYear = lastYear;
		this.image = image;
		this.biography = biography;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(biography, firstName, firstYear, id, image, lastName, lastYear);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		President other = (President) obj;
		return Objects.equals(biography, other.biography) && Objects.equals(firstName, other.firstName)
				&& firstYear == other.firstYear && id == other.id && Objects.equals(image, other.image)
				&& Objects.equals(lastName, other.lastName) && lastYear == other.lastYear;
	}
	@Override
	public String toString() {
		return "President [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", firstYear="
				+ firstYear + ", lastYear=" + lastYear + ", image=" + image + ", biography=" + biography + "]";
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getFirstYear() {
		return firstYear;
	}

	public void setFirstYear(int firstYear) {
		this.firstYear = firstYear;
	}

	public int getLastYear() {
		return lastYear;
	}

	public void setLastYear(int lastYear) {
		this.lastYear = lastYear;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getBiography() {
		return biography;
	}

	public void setBiography(String biography) {
		this.biography = biography;
	}
	
	
	
	
		
	
}
