package com.roifmr.presidents.integration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.roifmr.presidents.business.President;
import com.roifmr.presidents.integration.mapper.PresidentsMapper;

@Repository("presidentsDao")
public class PresidentsMyBatisDaoImpl implements PresidentsDao{

	@Autowired
	private PresidentsMapper mapper;

	@Override
	public List<President> queryForAllPresidents() {
		// TODO Auto-generated method stub
		List<President> presidents = null;
		presidents = mapper.getAllPresidents();
		return presidents;
	}

	@Override
	public String queryForPresidentBiography(int id) {
		// TODO Auto-generated method stub
		String bio = mapper.getBiographyById(id);
		return bio;
	}
}
