package com.roifmr.presidents.restservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.server.ServerErrorException;


import com.roifmr.presidents.business.President;
import com.roifmr.presidents.integration.PresidentsDao;
import com.roifmr.presidents.integration.PresidentsMyBatisDaoImpl;

@RestController
@RequestMapping("/president")
public class PresidentsService {

	private static final String DB_ERROR_MSG = 
			"Error communicating with the warehouse database";
	
	@Autowired
	private PresidentsDao dao;
	
	@GetMapping(value="/presidents",
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<President>> queryForAllPresidents() {
		ResponseEntity<List<President>> result;
	
		List<President> presidents;
		
		try {
			presidents = dao.queryForAllPresidents();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ServerErrorException(DB_ERROR_MSG, e);
			//throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error communicating with warehouse database", e);
		}
		if (presidents.size() > 0) {
			result = ResponseEntity.ok(presidents);
		}
		else {
			result = ResponseEntity.noContent().build();
			//throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No president in the list ");
		}
		return result;
	}
	
	@GetMapping(value="/president/{id}",
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> queryForBioById(@PathVariable int id) {
		ResponseEntity<String> result;
		String bio = null;
		
		try {
			bio = dao.queryForPresidentBiography(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ServerErrorException(DB_ERROR_MSG, e);
			//throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Error communicating with warehouse database", e);
		}
		if (bio == null) {
			result = ResponseEntity.noContent().build();
//			throw new ResponseStatusException(HttpStatus.NOT_FOUND, 
//					"No president in the list with id = " + id);
		}else {
			result = ResponseEntity.ok(bio);
		}
		
		return result;
	}
}
