-- HyperSQL schema definition for the countries table

-- drop the countries database table

drop table countries if exists;

create table countries (
	country_id integer, 
	name varchar(45), 
	region varchar(45), 
	population double, 
	area double, 
	population_density double, 
	per_capita_gdp double, 
	phones_per_thousand double
);
