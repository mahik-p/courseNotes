package com.fidelity.countries.integration;

import java.util.List;

import com.fidelity.countries.business.Country;

public interface CountryDao {
	List<String> queryForCountryNames();
	Country queryForCountryById(int id);
}
