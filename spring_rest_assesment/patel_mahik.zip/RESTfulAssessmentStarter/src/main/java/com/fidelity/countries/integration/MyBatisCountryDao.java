package com.fidelity.countries.integration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fidelity.countries.business.Country;
import com.fidelity.countries.integration.mapper.CountriesMapper;

@Repository
public class MyBatisCountryDao implements CountryDao{

	@Autowired
	CountriesMapper mapper;
	
	@Override
	public List<String> queryForCountryNames() {
		// TODO Auto-generated method stub
		List<String> result = null;
		result = mapper.findAllNames();
		return result;
	}

	@Override
	public Country queryForCountryById(int id) {
		// TODO Auto-generated method stub
		Country result = null;
		result = mapper.findCountry(id);
		return result;
	}
	
}
