package com.fidelity.countries.business;

import java.util.Objects;

public class Country {
	// DO NOT CHANGE THESE FIELD NAMES
	private int id;
	private String name;
	private String region;
	private double population;
	
	
	
	public Country(int id, String name, String region, double population) {
		super();
		this.id = id;
		this.name = name;
		this.region = region;
		this.population = population;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public double getPopulation() {
		return population;
	}
	public void setPopulation(double population) {
		this.population = population;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, name, population, region);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Country other = (Country) obj;
		return id == other.id && Objects.equals(name, other.name)
				&& Double.doubleToLongBits(population) == Double.doubleToLongBits(other.population)
				&& Objects.equals(region, other.region);
	}
	@Override
	public String toString() {
		return "Country [id=" + id + ", name=" + name + ", region=" + region + ", population=" + population + "]";
	}
	
	

}
