package com.fidelity.countries.restservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerErrorException;

import com.fidelity.countries.business.Country;
import com.fidelity.countries.integration.CountryDao;



@RestController
@RequestMapping("/countries")
public class CountriesService {

	private static final String DB_ERROR_MSG = 
			"Error communicating with the countries database";
	
	@Autowired
	private CountryDao dao;
	
	@GetMapping(value="/names",
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<String>> queryForAllNames() {
		ResponseEntity<List<String>> result = null;
		
		List<String> names;
		
		try {
			names = dao.queryForCountryNames();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ServerErrorException(DB_ERROR_MSG, e);
		}
		
		if (names.size() > 0) {
			result = ResponseEntity.ok(names);
		}else {
			result = ResponseEntity.noContent().build();
		}
		
		return result;
	}
	
	@GetMapping(value="/country/{id}",
			produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Country> queryForCountryById(@PathVariable int id) {
		ResponseEntity<Country> result = null;
		Country country = null;
		
		try {
			country = dao.queryForCountryById(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new ServerErrorException(DB_ERROR_MSG, e);
		}
		if (country == null) {
			result = ResponseEntity.noContent().build();
		}else {
			result = ResponseEntity.ok(country);
		}
		
		return result;
	}
}

















