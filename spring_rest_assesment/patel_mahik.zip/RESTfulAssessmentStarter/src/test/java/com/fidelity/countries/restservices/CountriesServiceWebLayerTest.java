package com.fidelity.countries.restservices;

import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fidelity.countries.business.Country;
import com.fidelity.countries.integration.CountryDao;


@WebMvcTest(CountriesService.class)
public class CountriesServiceWebLayerTest {

	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	CountryDao dao;
	
	private static List<String> names;
	
	private static Country country;
	
	@BeforeAll
	public static void init() {
		names = Arrays.asList("one", "two");
		country = new Country(1, "name", "region", 1.0);
	}
	
	@Test
	public void testQueryForAllNames() throws Exception {
		when(dao.queryForCountryNames()).thenReturn(names);
		
		mockMvc.perform(get("/countries/names"))
		   .andDo(print())
		   .andExpect(status().isOk())
		   .andExpect(jsonPath("$.length()").value(2));
	}
	
	@Test
	public void testQueryForAllNames_DaoReturnsEmptyList() throws Exception {
		when(dao.queryForCountryNames()).thenReturn(new ArrayList<String>());
				
		mockMvc.perform(get("/countries/names"))
			.andDo(print())
			.andExpect(status().isNoContent())
			.andExpect(content().string(is(emptyOrNullString())));
	}
	
	@Test
	public void testQueryForAllNames_DaoThrowsException() throws Exception {
		when(dao.queryForCountryNames()).thenThrow(new RuntimeException());		
		mockMvc.perform(get("/countries/names"))
			   .andDo(print())
			   .andExpect(status().is5xxServerError())
			   .andExpect(content().string(is(emptyOrNullString())));
	}
	
	@Test
	public void testQueryForAllCountryById() throws Exception {
		when(dao.queryForCountryById(1)).thenReturn(country);
		
		mockMvc.perform(get("/countries/country/1"))
		   .andDo(print())
		   .andExpect(status().isOk());	
	}
	
	@Test 
	public void testQueryForAllPresidentBio_DaoReturnsEmptyList() throws Exception {
		when(dao.queryForCountryById(1)).thenReturn(null);
		
		mockMvc.perform(get("/countries/country/1"))
			.andDo(print())
			.andExpect(status().isNoContent())
			.andExpect(content().string(is(emptyOrNullString())));
	}
	

	@Test 
	public void voidtestQueryForAllPresidentBio_DaoThrowsException() throws Exception{
		when(dao.queryForCountryById(1)).thenThrow(new RuntimeException());		
		mockMvc.perform(get("/countries/country/1"))
			   .andDo(print())
			   .andExpect(status().is5xxServerError())
			   .andExpect(content().string(is(emptyOrNullString())));
	}
}










