package com.fidelity.countries.restservices;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.jdbc.JdbcTestUtils;

import com.fidelity.countries.business.Country;



@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
@Sql({"classpath:schema.sql", "classpath:data.sql"}) 
public class CountriesServiceE2eTest {

	@Autowired
	private TestRestTemplate restTemplate;
	
	@Autowired
	private JdbcTemplate jdbcTemplate; 
	
	@Test
	public void testQueryForAllNames() {
		
		int nameCount = JdbcTestUtils.countRowsInTable(jdbcTemplate, "countries");
		
		String request = "/countries/names";
		
		ResponseEntity<String[]> response = restTemplate.getForEntity(request, String[].class);
		
		// verify the response HTTP status
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.OK)));
		
		// verify that the service returned all 
		String[] responseNames = response.getBody();
		assertThat(responseNames.length, is(equalTo(nameCount))); 
	}
	
	@Test
	public void testQueryForAllNames_NoCountriesInDb() {
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "countries");
		String request = "/countries/names";
		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		
		// verify that the response body is empty
		assertThat(response.getBody(), is(emptyOrNullString()));
	}
	
	@Test
	public void testQueryForAllNamesDbException() {
		// drop the countries table to force a database exception
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "countries");
		String request = "/countries/names";
		ResponseEntity<String> response = restTemplate.getForEntity(request, String.class);
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
	}
	
	
	@Test
	public void testQueryCountryUsingID() {
		String request = "/countries/country/1";
	
		ResponseEntity<Country> response = restTemplate.getForEntity(request,Country.class);
		
		// verify the response HTTP status
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.OK)));
		Country country = response.getBody();
		
		assertEquals(country.getId(), 1);

	}
	
	

	@Test
	public void testQueryForInvalidID() {
		String request = "/countries/country/0";
		
		ResponseEntity<Country> response = restTemplate.getForEntity(request,Country.class);
		
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
	}
	
	@Test
	public void testQueryForCountryById_DbException() {
		// drop the Widgets table to force a database exception
		JdbcTestUtils.deleteFromTables(jdbcTemplate, "countries");
		String request = "/countries/country/0";
		ResponseEntity<Country> response = restTemplate.getForEntity(request, Country.class);
		assertThat(response.getStatusCode(), is(equalTo(HttpStatus.NO_CONTENT)));
	}
}









