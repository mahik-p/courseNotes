package com.fidelity.countries.restservices;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.server.ResponseStatusException;

import com.fidelity.countries.business.Country;
import com.fidelity.countries.integration.CountryDao;


class CountryServicePojoUnitTest {

	@Mock
	CountryDao dao;
	
	@InjectMocks
	private CountriesService service;
	
	@BeforeEach
	public void setUp() {
		service = new CountriesService();
		
		MockitoAnnotations.openMocks(this); // required initialize all mocks
	}
	
	@Test
	public void testQueryForAllNames_ListLength2_ReturnsStatus200() {
		// Initialize the list
		List<String> names = Arrays.asList(
				"one", "two"
				);
		// Configure the mock DAO to return the list  

		when( dao.queryForCountryNames() )
        .thenReturn(names);
		
		
		// call a service method with a plain Java call: no HTTP request is created
		ResponseEntity<List<String>> response = service.queryForAllNames();
		
		// Verify correct HTTP status
		assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
		
		// Verify response body content
		assertThat(response.getBody(), equalTo(names));
		
	}
	
	@Test
	public void testQueryForAllNames_EmptyList_ReturnsStatus204() {
		// Configure the mock DAO to return an empty list 
		when( dao.queryForCountryNames() )
		             .thenReturn(new ArrayList<String>());

		ResponseEntity<List<String>> response = service.queryForAllNames();
		
		assertThat(response.getStatusCode(), equalTo(HttpStatus.NO_CONTENT));
		assertThat(response.getBody(), is(nullValue()));
	}
	
	
	@Test
	public void testQueryForAllNames_DaoThrowsException_ReturnsStatus500() {
		// Configure the mock DAO to throw an unchecked exception
		when( dao.queryForCountryNames() )
		             .thenThrow(new IllegalStateException());

		ResponseStatusException ex = assertThrows(ResponseStatusException.class, () ->
			service.queryForAllNames()
		);
		
		assertThat(ex.getStatus(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
	}
	
	@Test
	public void testQueryCountryById_returns200() {
		
		Country country = new Country(1, "name", "region", 1.0);
		// Configure the mock DAO
		when( dao.queryForCountryById(1) )
        .thenReturn(country);
		
		
		ResponseEntity<Country> response = service.queryForCountryById(1);
		
		// Verify correct HTTP status
		assertThat(response.getStatusCode(), equalTo(HttpStatus.OK));
		
		// Verify response body content
		assertThat(response.getBody(), equalTo(country));
	}
	
	@Test
	public void testQueryCountryById_return204() {
		// Configure the mock DAO to return an empty list 

		when( dao.queryForCountryById(1))
		             .thenReturn(null);

		ResponseEntity<Country> response = service.queryForCountryById(1);
		
		assertThat(response.getStatusCode(), equalTo(HttpStatus.NO_CONTENT));
		assertThat(response.getBody(), is(nullValue()));
	}
	
	@Test 
	public void testQueryCountryById_return500() {
		// Configure the mock DAO to throw an unchecked exception 
		when( dao.queryForCountryById(1) )
		             .thenThrow(new IllegalStateException());

		ResponseStatusException ex = assertThrows(ResponseStatusException.class, () ->
			service.queryForCountryById(1)
		);
		
		assertThat(ex.getStatus(), equalTo(HttpStatus.INTERNAL_SERVER_ERROR));
	}
	
}
