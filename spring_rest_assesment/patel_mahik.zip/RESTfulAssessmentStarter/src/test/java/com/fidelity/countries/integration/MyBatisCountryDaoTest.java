package com.fidelity.countries.integration;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.fidelity.countries.business.Country;



@SpringBootTest
@Transactional
class MyBatisCountryDaoTest {

	@Autowired 
	CountryDao dao;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Test 
	public void queryForAllNames() {
		List<String> p = dao.queryForCountryNames();
		
		assertEquals(p.size(), 14);
	}
	
	@Test
	public void queryForCountryById() {
		Country c = dao.queryForCountryById(1);
		assertEquals(c.getId(), 1);
		assertEquals(c.getName(), "Afghanistan");
	}
}
